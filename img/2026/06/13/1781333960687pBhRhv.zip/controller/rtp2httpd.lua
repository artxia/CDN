-- Copyright 2024 rtp2httpd
-- Licensed to the public under the GNU General Public License v2.

module("luci.controller.rtp2httpd", package.seeall)

function index()
	if not nixio.fs.access("/etc/config/rtp2httpd") then
		return
	end

	entry({"admin", "services", "rtp2httpd"}, cbi("rtp2httpd"), _("rtp2httpd"), 60)
end

-- Copyright 2024 rtp2httpd
-- Licensed to the public under the GNU General Public License v2.

local sys = require "luci.sys"
local fs = require "nixio.fs"

m = Map("rtp2httpd", translate("rtp2httpd"), 
	translate("rtp2httpd converts RTP/UDP/RTSP media into http stream. Here you can configure the settings."))

-- Restart service after saving configuration
m.on_after_commit = function(self)
	luci.sys.call("/etc/init.d/rtp2httpd restart >/dev/null 2>&1 &")
end

s = m:section(TypedSection, "rtp2httpd", "")
s.anonymous = true
s.addremove = false

-- Create tabs
s:tab("basic", translate("Basic Settings"))
s:tab("network", translate("Network & Performance"))
s:tab("player", translate("Player & M3U"))
s:tab("advanced", translate("Monitoring & Advanced"))

-- ===== TAB 1: Basic Settings =====

enabled = s:taboption("basic", Flag, "disabled", translate("Enabled"))
enabled.enabled = "0"
enabled.disabled = "1"
enabled.default = enabled.enabled
enabled.rmempty = false

respawn = s:taboption("basic", Flag, "respawn", translate("Respawn"), 
	translate("Auto restart after crash"))
respawn.default = "1"

use_config_file = s:taboption("basic", Flag, "use_config_file", translate("Use Config File"),
	translate("Use config file instead of individual options"))
use_config_file.default = "0"
use_config_file.rmempty = true

config_file_content = s:taboption("basic", TextValue, "_config_file_content", translate("Config File Content"),
	translate("Edit the content of /etc/rtp2httpd.conf"))
config_file_content.rows = 20
config_file_content.wrap = "off"
config_file_content.rmempty = true
config_file_content:depends("use_config_file", "1")
function config_file_content.cfgvalue(self, section)
	return fs.readfile("/etc/rtp2httpd.conf") or ""
end
function config_file_content.write(self, section, value)
	if value then
		fs.writefile("/etc/rtp2httpd.conf", value:gsub("\r\n", "\n"))
	end
end

port = s:taboption("basic", Value, "port", translate("Port"))
port.datatype = "port"
port.placeholder = "5140"
port.rmempty = true

verbose = s:taboption("basic", ListValue, "verbose", translate("Logging level"))
verbose:value("0", "Fatal")
verbose:value("1", "Error")
verbose:value("2", "Warn")
verbose:value("3", "Info")
verbose:value("4", "Debug")
verbose.default = "1"

-- ===== TAB 2: Network & Performance =====

advanced_interface = s:taboption("network", Flag, "advanced_interface_settings", 
	translate("Advanced Interface Settings"),
	translate("Configure separate interfaces for multicast, FCC and RTSP"))
advanced_interface.default = "0"
advanced_interface.rmempty = true

-- Simple interface setting (shown by default, hidden when advanced is enabled)
upstream_interface = s:taboption("network", Value, "upstream_interface", 
	translate("Upstream Interface"),
	translate("Default interface for all upstream traffic (multicast, FCC and RTSP). Leave empty to use routing table."))
upstream_interface.rmempty = true
for _, e in ipairs(sys.net.devices()) do
	if e ~= "lo" then upstream_interface:value(e) end
end
function upstream_interface.cfgvalue(self, section)
	local advanced = m:get(section, "advanced_interface_settings")
	if advanced == "1" then
		return nil  -- Hide when advanced mode is enabled
	end
	return Value.cfgvalue(self, section)
end
function upstream_interface.write(self, section, value)
	local advanced = m:get(section, "advanced_interface_settings")
	if advanced ~= "1" then
		Value.write(self, section, value)
	end
end

-- Advanced interface settings
upstream_multicast = s:taboption("network", Value, "upstream_interface_multicast",
	translate("Upstream Multicast Interface"),
	translate("Interface to use for multicast (RTP/UDP) upstream media stream (default: use routing table)"))
upstream_multicast.rmempty = true
for _, e in ipairs(sys.net.devices()) do
	if e ~= "lo" then upstream_multicast:value(e) end
end
upstream_multicast:depends("advanced_interface_settings", "1")

upstream_fcc = s:taboption("network", Value, "upstream_interface_fcc",
	translate("Upstream FCC Interface"),
	translate("Interface to use for FCC unicast upstream media stream (default: use routing table)"))
upstream_fcc.rmempty = true
for _, e in ipairs(sys.net.devices()) do
	if e ~= "lo" then upstream_fcc:value(e) end
end
upstream_fcc:depends("advanced_interface_settings", "1")

upstream_rtsp = s:taboption("network", Value, "upstream_interface_rtsp",
	translate("Upstream RTSP Interface"),
	translate("Interface to use for RTSP unicast upstream media stream (default: use routing table)"))
upstream_rtsp.rmempty = true
for _, e in ipairs(sys.net.devices()) do
	if e ~= "lo" then upstream_rtsp:value(e) end
end
upstream_rtsp:depends("advanced_interface_settings", "1")

maxclients = s:taboption("network", Value, "maxclients", translate("Max clients allowed"))
maxclients.datatype = "range(1, 5000)"
maxclients.placeholder = "5"
maxclients.rmempty = true

workers = s:taboption("network", Value, "workers", translate("Workers"),
	translate("Number of worker processes. Set to 1 for resource-constrained devices, or CPU cores for best performance."))
workers.datatype = "range(1, 64)"
workers.rmempty = true
workers.placeholder = "1"

buffer_pool = s:taboption("network", Value, "buffer_pool_max_size", 
	translate("Buffer Pool Max Size"),
	translate("Maximum number of buffers in zero-copy pool. Each buffer is 1536 bytes. Default is 16384 (~24MB). Increase to improve throughput for multi-client concurrency."))
buffer_pool.datatype = "range(1024, 1048576)"
buffer_pool.rmempty = true
buffer_pool.placeholder = "16384"

mcast_rejoin = s:taboption("network", Value, "mcast_rejoin_interval",
	translate("Multicast Rejoin Interval"),
	translate("Periodic multicast rejoin interval in seconds (0=disabled, default 0). Enable this (e.g., 30-120 seconds) if your network switches timeout multicast memberships due to missing IGMP Query messages. Only use when experiencing multicast stream interruptions."))
mcast_rejoin.datatype = "range(0, 86400)"
mcast_rejoin.rmempty = true
mcast_rejoin.placeholder = "0"

fcc_port_range = s:taboption("network", Value, "fcc_listen_port_range",
	translate("FCC Listen Port Range"),
	translate("Local UDP port range for FCC client sockets (format: start-end, e.g., 40000-40100). Leave empty to use random ports."))
fcc_port_range.placeholder = "begin-end"
fcc_port_range.rmempty = true

zerocopy = s:taboption("network", Flag, "zerocopy_on_send", translate("Zero-Copy on Send"),
	translate("Enable zero-copy send with MSG_ZEROCOPY for better performance. Requires kernel 4.14+ (MSG_ZEROCOPY support). On supported devices, this can improve throughput and reduce CPU usage, especially under high concurrent load. Recommended only when experiencing performance bottlenecks."))
zerocopy.default = "0"
zerocopy.rmempty = true

-- ===== TAB 3: Player & M3U =====

external_m3u = s:taboption("player", Value, "external_m3u", translate("External M3U"),
	translate("Fetch M3U playlist from a URL (file://, http://, https:// supported). Example: https://example.com/playlist.m3u or file:///path/to/playlist.m3u"))
external_m3u.placeholder = "https://example.com/playlist.m3u"
external_m3u.rmempty = true

m3u_interval = s:taboption("player", Value, "external_m3u_update_interval",
	translate("External M3U Update Interval"),
	translate("External M3U automatic update interval in seconds (default: 7200 = 2 hours). Set to 0 to disable automatic updates."))
m3u_interval.datatype = "uinteger"
m3u_interval.placeholder = "7200"
m3u_interval.rmempty = true

player_path = s:taboption("player", Value, "player_page_path",
	translate("Player Page Path"),
	translate("URL path for the player page (default: /player)"))
player_path.placeholder = "/player"
player_path.rmempty = true

-- Player page button
player_button = s:taboption("player", DummyValue, "_player_button", translate("Player Page"))
player_button.rawhtml = true
function player_button.cfgvalue(self, section)
	local port = m:get(section, "port") or "5140"
	local player_path_val = m:get(section, "player_page_path") or "/player"
	local token = m:get(section, "r2h_token") or ""
	local url = "http://" .. luci.http.getenv("SERVER_ADDR") .. ":" .. port .. player_path_val
	if token ~= "" then
		url = url .. "?r2h-token=" .. token
	end
	return '<a href="' .. url .. '" target="_blank" class="btn cbi-button cbi-button-apply">' .. translate("Open Player Page") .. '</a>'
end

-- ===== TAB 4: Monitoring & Advanced =====

-- Status dashboard button
status_button = s:taboption("advanced", DummyValue, "_status_button", translate("Status Dashboard"))
status_button.rawhtml = true
function status_button.cfgvalue(self, section)
	local port = m:get(section, "port") or "5140"
	local status_path_val = m:get(section, "status_page_path") or "/status"
	local token = m:get(section, "r2h_token") or ""
	local url = "http://" .. luci.http.getenv("SERVER_ADDR") .. ":" .. port .. status_path_val
	if token ~= "" then
		url = url .. "?r2h-token=" .. token
	end
	return '<a href="' .. url .. '" target="_blank" class="btn cbi-button cbi-button-apply">' .. translate("Open Status Dashboard") .. '</a>'
end

status_path = s:taboption("advanced", Value, "status_page_path",
	translate("Status Page Path"),
	translate("URL path for the status page (default: /status)"))
status_path.placeholder = "/status"
status_path.rmempty = true

hostname = s:taboption("advanced", Value, "hostname", translate("Hostname"),
	translate("When configured, HTTP Host header will be checked and must match this value to allow access."))
hostname.rmempty = true

r2h_token = s:taboption("advanced", Value, "r2h_token", translate("R2H Token"),
	translate("If set, all HTTP requests must include r2h-token query parameter with matching value (e.g., http://server:port/rtp/ip:port?fcc=ip:port&r2h-token=your-token)"))
r2h_token.rmempty = true

xff = s:taboption("advanced", Flag, "xff", translate("X-Forwarded-For"),
	translate("When enabled, uses HTTP X-Forwarded-For header as client address for status page display. Also accepts X-Forwarded-Host / X-Forwarded-Proto headers as the base URL for M3U playlist conversion. Only enable when running behind a reverse proxy."))
xff.default = "0"
xff.rmempty = true

video_snapshot = s:taboption("advanced", Flag, "video_snapshot", translate("Video Snapshot"),
	translate("Enable video snapshot feature. When enabled, clients can request snapshots with snapshot=1 query parameter"))
video_snapshot.default = "0"
video_snapshot.rmempty = true

ffmpeg_path = s:taboption("advanced", Value, "ffmpeg_path", translate("FFmpeg Path"),
	translate("Path to FFmpeg executable. Leave empty to use system PATH (default: ffmpeg)"))
ffmpeg_path.placeholder = "ffmpeg"
ffmpeg_path.rmempty = true
ffmpeg_path:depends("video_snapshot", "1")

ffmpeg_args = s:taboption("advanced", Value, "ffmpeg_args", translate("FFmpeg Arguments"),
	translate("Additional FFmpeg arguments for snapshot generation. Common options: -hwaccel none, -hwaccel auto, -hwaccel vaapi (for Intel GPU)"))
ffmpeg_args.placeholder = "-hwaccel none"
ffmpeg_args.rmempty = true
ffmpeg_args:depends("video_snapshot", "1")

return m
